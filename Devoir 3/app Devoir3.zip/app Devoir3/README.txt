Fonctionnement 


Menu principale
--------------------------------
    On a le choix entre  3 "Connexion","S'inscrire Comme resident" et "S'inscrire Comme Consomateur"
action au quelle on peux accéder en tapant le numéros corespondant 

Si on tape 1 on accede "Connexion" dans le quelle on nous demande votre email puis 
mot de passe si un utilisateur correspond vous serrais connecter au menus aproprier 
selon votre statut ( Menu Consomateur ou Menu Resident)

Si on tape 2 on accede "S'inscrire Comme resident" on vous demande les information suivante:
-Nom
-Prenom
-Mot de passe
-Numero de telephone
-Email
-Adresse
-Le code unique fourni par la municipaliter
Votre dossier va etres ajouter a une list dutilisateur en attante de validation 
puis vous serais rediriger vers le menu Princiapele


Si on tape 2 on accede "S'inscrire Comme Consomateur" on vous demande les information suivante:
-Nom
-Adresse
-Mot de passe
-Email
-Numero de telephone
-Activiter
-Capaciter de traitment
-Le code unique fourni par la municipaliter
Votre dossier va etres ajouter a une list dutilisateur en attante de validation 
puis vous serais rediriger vers le menu Princiapele
-----------------------------
Menu Consomateur

On a le choix entre  2 "Revenir au menus principale" et "Notifier les résidents"
action au quelle on peux accéder en tapant le numéros corespondant 

Si on tape 0 on accede "Revenir au menus principale" on revient au menu principale

Si on tape 1 on accede "Notifier les résidents" on rentre a message pour quil soit envoyer au resident

-----------------------------

Menu Resident
le menu  resident ofre les 7 action suivante

Si on tape 0 on accede "Revenir au menus principale":
    Revient au Menu principale
    
Si on tape 1 on accede "Enregistrer un bac"
    on vous demande les information suivante:
        -code qr
        -Adresse
        -la Date d'emission
        -Enter le type du bac
    Ensuite le bac a ete ajouter est enregistrer

Si on tape 2 on accede "Afficher l'état des mes bacs"
    Affiche pour chaque bac sont type son id et sont remplisage
Si on tape 3 on accede "Métriques"
Si on tape 4 on accede "Voir l'état de traitement des déchets municipaux"
    pour chaque lots de dechet en traitment on afiche:
        -le Numero
        -le type de dechet
        -Date de passage des camions
        -Staut
        -les consomateur qui rentre dans le processus
Si on tape 5 on accede "Signaler un problème à MunicipInfo"
    vous demande de rentrer un message qui seras transmis
Si on tape 6 on accede "Trouver un consommateur"
    un nouveaus menus s'affiche avec 3 options
        Si on tape 0 on accede "Retour menu Resident"
            Retourne au menus de resident
        Si on tape 1 on accede "Chercher pas nom"
            si on trouve le consomateur on afiche sont nom
            puis un menus s'afiche 
                -soit on tape 0 pour revenir au menu resident 
                -soit on tape 1 pour donner une note
        Si on tape 2 on accede "Chercher par type"
            Afiche une list des nom des consomateur qui traite se type de dechet




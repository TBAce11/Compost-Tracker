

public class Utilisateur {
    
    protected int id;
    protected String Nom ;
    protected String Mdp ;
    protected String Email  ;
        
        
        
        
        public Utilisateur () {}

    //------------------- Methode
    

    //--------- getters
    
    
    public int getid() {
        return id;
    } 
    public String getNom() {
        return Nom;
    } 
    public String getMdp() {
        return Mdp;
    } 
    public String getEmail() {
        return Email;
    } 

   
    //--------- setters
    
        
        
      

       
       
}
